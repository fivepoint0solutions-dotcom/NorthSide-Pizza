import React, { useMemo, useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';

/* =====================================================================================
   3D PROPERTY EXPERIENCE — layered real-time WebGL architecture
   -------------------------------------------------------------------------------------
   PHOTO-MATCHED RECONSTRUCTION:
     Every listing renders its OWN house, reconstructed from the listing's exterior
     photo. PHOTO_PROFILES below records what each photo shows — roof form and colour,
     storeys, cladding colour, porches, garages, chimneys, dormers, glazing — and the
     generator builds the model from that profile on top of the listing's specs
     (beds, baths, sqft, type). The same listing always renders the same house.

   SCENE LAYERS (independent, composable):
     1. ARCHITECTURE  — floor slab, structural walls, glazing, built-in millwork,
                        porch, garage. Always on.
     2. ROOF          — separate structural group (incl. dormers + chimney). ROOF OFF
                        lifts it away in real 3D and fades it out to reveal the floor plan.
     3. FURNISHING    — separate staging layer, generated per spec (one bed per bedroom,
                        dining set sized to the home). Every asset is an individually
                        addressable node registered in the furniture registry.

   FUTURE EXTENSION (product selection / shopping):
     - Each furniture asset carries metadata (id, name, category, room, productId=null).
     - Assets are already individually selectable (click → inspect). When products launch,
       attach a productId/SKU per registry entry and render commerce UI from the same
       selection event — no scene restructuring required.
     - For a production GLTF digital twin of a real listing, pass modelUrl and name nodes
       with layer prefixes (`arch_*`, `roof_*`, `furn_*`); classifyModelLayers() below
       splits them and the same ROOF / FURNISHING toggles drive the imported model.
   ===================================================================================== */

const PALETTE = {
  pine: '#263F35',
  teal: '#28717A',
  olive: '#87965B',
  bark: '#76533F',
  sand: '#E7E0D2',
};

/* ---------------------------------- GLTF ADAPTER ---------------------------------- */
/**
 * Layer classifier for a future production GLTF model.
 * Convention: node names prefixed `roof_` → roof layer, `furn_` → furnishing layer,
 * `arch_` → architecture. Returns three groups ready to be driven by the exact same
 * roofOn / furnished state used for the generated model below.
 */
export function classifyModelLayers(root: THREE.Object3D): {
  architecture: THREE.Object3D[];
  roof: THREE.Object3D[];
  furnishing: THREE.Object3D[];
} {
  const architecture: THREE.Object3D[] = [];
  const roof: THREE.Object3D[] = [];
  const furnishing: THREE.Object3D[] = [];
  root.traverse((node) => {
    if (node.name.startsWith('roof_')) roof.push(node);
    else if (node.name.startsWith('furn_')) furnishing.push(node);
    else if (node.name.startsWith('arch_')) architecture.push(node);
  });
  return { architecture, roof, furnishing };
}

/* --------------------------- PER-PROPERTY HOUSE SPEC ------------------------------- */
export interface PropertySpecInput {
  id?: string;
  beds?: number;
  baths?: number;
  sqft?: number;
  type?: string; // 'House' | 'Condo' | 'Townhome' | 'Estate' | 'Cottage'
}

export interface HouseSpec {
  seed: number;
  width: number;        // exterior footprint, metres (x axis)
  depth: number;        // exterior footprint, metres (z axis)
  wallH: number;        // one storey height
  storeys: number;
  totalH: number;       // wall top height (all storeys)
  roofStyle: 'gable' | 'steep' | 'flat' | 'hip';
  roofRise: number;     // ridge height above wall top
  bedrooms: number;
  partitionX: number;   // wall separating open-plan living from the bedroom wing
  wallColor: string;
  roofColor: string;
  floorColor: string;
  glassColor: string;
  accentColor?: string; // contrasting cladding band / volume (from the photo)
  glassBoost: boolean;  // photo shows floor-to-ceiling glazing
  porch?: 'flat' | 'gable';
  garage?: boolean;
  chimney?: boolean;
  dormers?: number;
  label: string;        // human summary of the generated plan
}

/**
 * What each listing's photo shows. Reconstructed by visual inspection of the
 * listing photography: roof form + colour, cladding, storeys, and features.
 * Listings whose photo is an interior shot get a type-appropriate exterior massing.
 */
const PHOTO_PROFILES: Record<string, Partial<HouseSpec>> = {
  'wcr-001': { wallColor: '#2e2a25', roofColor: '#26221f', roofStyle: 'flat', storeys: 2, glassBoost: true },                                    // black cedar modern, glass walls
  'wcr-002': { wallColor: '#6b4a36', roofColor: '#3a3a40', roofStyle: 'steep', storeys: 2, chimney: true, dormers: 1, porch: 'gable' },          // brown timber gables, stone chimney
  'wcr-003': { wallColor: '#f2f0ec', roofColor: '#3f3a35', roofStyle: 'flat', glassBoost: true },                                                // penthouse interior photo → modern condo
  'wcr-004': { wallColor: '#f3f1eb', roofColor: '#e8e5de', roofStyle: 'flat', glassBoost: true },                                                // crisp white modern villa
  'wcr-005': { wallColor: '#f4f2ec', roofColor: '#5a5e63', roofStyle: 'gable', storeys: 2, dormers: 2, porch: 'flat' },                          // white colonial, grey shingles, porch, dormers
  'wcr-006': { wallColor: '#f2f1ec', roofColor: '#e6e3dc', roofStyle: 'flat', storeys: 2, glassBoost: true },                                    // white cubic villa, balconies
  'wcr-007': { wallColor: '#f0ede6', roofColor: '#e2ded6', roofStyle: 'flat', storeys: 2, accentColor: '#b06a4a' },                              // white + terracotta wood accent
  'wcr-008': { wallColor: '#d8cfc2', roofColor: '#4a443c', roofStyle: 'flat', accentColor: '#8a5f43' },                                          // townhome interior photo → warm modern rowhouse
  'wcr-009': { wallColor: '#7a4a34', roofColor: '#3b4450', roofStyle: 'steep', dormers: 1 },                                                     // red-brown forest cabin, blue-grey shingles
  'wcr-010': { wallColor: '#9a8f82', roofColor: '#3c3835', roofStyle: 'flat', glassBoost: true },                                                // loft interior photo → industrial warehouse block
  'wcr-011': { wallColor: '#f6f4ee', roofColor: '#b3362b', roofStyle: 'steep', dormers: 2, porch: 'gable' },                                     // white cottage, red metal roof
  'wcr-012': { wallColor: '#6a4632', roofColor: '#4a4038', roofStyle: 'gable', glassBoost: true },                                               // cabin interior photo → waterfront cedar cabin
  'wcr-013': { wallColor: '#f0efe9', roofColor: '#e9e7e0', roofStyle: 'flat' },                                                                  // white geometric villa
  'wcr-014': { wallColor: '#e3ddd2', roofColor: '#4a443c', roofStyle: 'flat' },                                                                  // apartment interior photo → condo block
  'wcr-015': { wallColor: '#f2efe8', roofColor: '#4a443c', roofStyle: 'flat' },                                                                  // condo interior photo → light condo block
  'wcr-016': { wallColor: '#f0ede6', roofColor: '#5a554e', roofStyle: 'flat', accentColor: '#a85f3d', garage: true },                            // white + rust accent, garage door
  'wcr-017': { wallColor: '#f3f1ec', roofColor: '#e7e4dd', roofStyle: 'flat', storeys: 2, porch: 'flat', glassBoost: true },                     // white villa, covered terrace
  'wcr-018': { wallColor: '#7e3f2c', roofColor: '#4b3d33', roofStyle: 'steep', storeys: 2, chimney: true },                                      // red brick craftsman, steep gables
  'wcr-019': { wallColor: '#efe9dc', roofColor: '#6a5a48', roofStyle: 'gable' },                                                                 // cottage interior photo → restored gabled cottage
  'wcr-020': { wallColor: '#f1ead9', roofColor: '#a5533a', roofStyle: 'hip', chimney: true, porch: 'flat' },                                     // Mediterranean stucco, terracotta hip roof
};

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

/** Deterministic string hash → stable per-listing seed. */
function hashSeed(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

/** Tiny seeded PRNG (mulberry32) for stable per-listing variation. */
function seededRandom(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const WALL_TONES = ['#f0e9da', '#ece2cf', '#e6ddcb', '#efe6d4', '#e9dfd0'];
const ROOF_TONES = ['#4a3b30', '#3f3a35', '#54443a', '#463f38', '#503e33'];
const FLOOR_TONES = ['#b18a62', '#a87f58', '#b5906b', '#a9835d'];

/**
 * Turn listing specs + the photo profile into an architectural spec.
 * Deterministic: the same property always generates the same home.
 */
export function generateHouseSpec(input: PropertySpecInput = {}): HouseSpec {
  const seed = hashSeed(input.id ?? `${input.sqft ?? 2400}-${input.beds ?? 3}-${input.type ?? 'House'}`);
  const rand = seededRandom(seed);

  const sqft = clamp(input.sqft ?? 2400, 400, 12000);
  const bedrooms = clamp(Math.round(input.beds ?? 3), 1, 6);
  const type = input.type ?? 'House';

  const profile: Partial<HouseSpec> = (input.id && PHOTO_PROFILES[input.id]) || {};

  const storeys = profile.storeys ?? (type === 'Condo' || type === 'Townhome' ? 1 : sqft >= 3800 ? 2 : 1);
  const footprint = (sqft * 0.0929) / storeys; // m² per level

  let width = Math.sqrt(footprint * (1.5 + rand() * 0.4)); // aspect 1.5–1.9
  width = clamp(width, 8, 18);
  const depth = clamp(footprint / width, 5.5, 12);

  const wallH = type === 'Estate' ? 3.4 : type === 'Condo' ? 2.9 : 3.1;
  const totalH = storeys > 1 ? wallH * 1.85 : wallH;

  const roofStyle = profile.roofStyle ?? (type === 'Condo' ? 'flat' : type === 'Cottage' ? 'steep' : 'gable');
  const halfSpan = depth / 2 + 0.6;
  const roofRise =
    roofStyle === 'flat' ? 0.35
    : roofStyle === 'steep' ? halfSpan * 0.85
    : roofStyle === 'hip' ? halfSpan * 0.55
    : halfSpan * (0.4 + rand() * 0.1);

  // Open-plan living/dining/kitchen takes the west ~58%; bedroom wing the rest.
  const partitionX = -width / 2 + width * (bedrooms >= 4 ? 0.52 : 0.58);

  const pick = <T,>(arr: T[]) => arr[Math.floor(rand() * arr.length)];
  const roofName = roofStyle === 'flat' ? 'flat roof' : roofStyle === 'steep' ? 'steep pitched roof' : roofStyle === 'hip' ? 'hip roof' : 'pitched roof';
  return {
    seed,
    width,
    depth,
    wallH,
    storeys,
    totalH,
    roofStyle,
    roofRise,
    bedrooms,
    partitionX,
    wallColor: profile.wallColor ?? pick(WALL_TONES),
    roofColor: profile.roofColor ?? pick(ROOF_TONES),
    floorColor: pick(FLOOR_TONES),
    glassColor: '#8fb0b3',
    accentColor: profile.accentColor,
    glassBoost: profile.glassBoost ?? false,
    porch: profile.porch,
    garage: profile.garage,
    chimney: profile.chimney,
    dormers: profile.dormers ?? 0,
    label: `${bedrooms} bed · ${storeys} ${storeys > 1 ? 'storeys' : 'storey'} · ${roofName} — matched to listing photo`,
  };
}

/* ------------------------------ FURNITURE REGISTRY --------------------------------- */
export interface FurnitureAssetMeta {
  id: string;            // stable asset id — future product key
  name: string;
  category: string;      // e.g. Seating, Table, Lighting, Decor, Textile, Art
  room: string;
  kind: string;          // renderer key in FURNITURE_RENDERERS
  selectable: boolean;   // product-selection architecture flag
  productId: string | null; // FUTURE: link to commerce catalogue
}

export interface FurniturePlacement {
  meta: FurnitureAssetMeta;
  position: V3;
  rotationY?: number;
}

/**
 * Generate the staging set for a given house spec: one bed per bedroom, a dining set
 * sized to the home, living-room set, lighting and decor. Returns the registry plus a
 * placement map — the same shape a future per-listing staging catalogue would produce.
 */
export function buildFurniturePlan(spec: HouseSpec): FurniturePlacement[] {
  const W = spec.width, D = spec.depth;
  const x0 = -W / 2;
  const items: FurniturePlacement[] = [];
  const add = (
    kind: string, name: string, category: string, room: string,
    position: V3, rotationY?: number,
  ) => {
    const id = `furn_${kind}_${items.length}`;
    items.push({
      meta: { id, name, category, room, kind, selectable: true, productId: null },
      position,
      rotationY,
    });
  };

  // — Great room (west end) —
  const lx = x0 + W * 0.16;
  add('rug', 'Hand-Knotted Wool Rug', 'Textile', 'Great Room', [lx, 0, -0.3]);
  add('sofa', 'Linen Three-Seat Sofa', 'Seating', 'Great Room', [lx, 0, -1.2]);
  add('coffee_table', 'White Oak Coffee Table', 'Table', 'Great Room', [lx, 0, 0.4]);
  add('floor_lamp', 'Arc Floor Lamp', 'Lighting', 'Great Room', [x0 + 0.8, 0, -D / 2 + 1.0]);
  add('media_console', 'Walnut Media Console', 'Storage', 'Great Room', [lx, 0, D / 2 - 0.7]);
  add('art_triptych', 'Coastal Triptych Art', 'Art', 'Great Room', [lx, 0, -D / 2 + 0.18]);
  add('plant', 'Potted Olive Tree', 'Decor', 'Great Room', [x0 + 0.8, 0, D / 2 - 1.0]);

  // — Dining (middle of the open plan, beside the kitchen) —
  const dx = x0 + W * 0.42;
  add('dining_table', 'Live-Edge Dining Table', 'Table', 'Dining', [dx, 0, D * 0.12]);
  const chairSpots: Array<[number, number, number]> = [
    [-0.7, -0.95, 0], [0.7, -0.95, 0], [-0.7, 0.95, Math.PI], [0.7, 0.95, Math.PI],
  ];
  if (spec.bedrooms >= 4) chairSpots.push([-1.5, -0.95, 0], [-1.5, 0.95, Math.PI]);
  chairSpots.forEach(([ox, oz, rot]) =>
    add('chair', 'Dining Chair', 'Seating', 'Dining', [dx + ox, 0, D * 0.12 + oz], rot),
  );
  add('pendant', 'Ceramic Pendant Light', 'Lighting', 'Dining', [dx, 0, D * 0.12]);

  // — Bedroom wing (east of the partition, stacked along z) —
  const seg = D / spec.bedrooms;
  const wingCx = (spec.partitionX + W / 2) / 2;
  for (let i = 0; i < spec.bedrooms; i++) {
    const zc = -D / 2 + seg * (i + 0.5);
    const room = i === 0 ? 'Primary Suite' : `Bedroom ${i + 1}`;
    const kind = i === 0 ? 'bed_king' : i % 2 === 1 ? 'bed_queen' : 'bed_twin';
    const name = i === 0 ? 'King Platform Bed' : i % 2 === 1 ? 'Queen Bed' : 'Twin Bed';
    add(kind, name, 'Bed', room, [wingCx, 0, zc], Math.PI / 2);
    if (i === 0) {
      add('nightstand', 'Nightstand', 'Storage', room, [wingCx - 1.4, 0, zc - 1.6]);
      add('table_lamp', 'Table Lamp', 'Lighting', room, [wingCx - 1.4, 0, zc - 1.6]);
      add('nightstand', 'Nightstand', 'Storage', room, [wingCx - 1.4, 0, zc + 1.6]);
      add('table_lamp', 'Table Lamp', 'Lighting', room, [wingCx - 1.4, 0, zc + 1.6]);
      add('art_print', 'Framed Ocean Print', 'Art', room, [W / 2 - 0.18, 0, zc], -Math.PI / 2);
    }
  }
  return items;
}

/** Default registry (3-bed showcase) — kept for backward compatibility. */
export const FURNITURE_REGISTRY: FurnitureAssetMeta[] =
  buildFurniturePlan(generateHouseSpec({ id: 'default', beds: 3, sqft: 2400, type: 'House' })).map((p) => p.meta);

/* ------------------------------- MESH PRIMITIVES ----------------------------------- */
type V3 = [number, number, number];

function Box({ p, s, c, hot }: { p: V3; s: V3; c: string; hot?: boolean }) {
  return (
    <mesh position={p} castShadow receiveShadow>
      <boxGeometry args={s} />
      <meshStandardMaterial color={c} emissive={hot ? PALETTE.teal : '#000000'} emissiveIntensity={hot ? 0.45 : 0} roughness={0.85} />
    </mesh>
  );
}

function Cyl({ p, r, h, c, hot }: { p: V3; r: number; h: number; c: string; hot?: boolean }) {
  return (
    <mesh position={p} castShadow receiveShadow>
      <cylinderGeometry args={[r, r, h, 20]} />
      <meshStandardMaterial color={c} emissive={hot ? PALETTE.teal : '#000000'} emissiveIntensity={hot ? 0.45 : 0} roughness={0.8} />
    </mesh>
  );
}

/* --------------------------- FURNITURE ASSET RENDERERS ----------------------------- */
/** Each renderer draws one asset centred on its local origin (floor = y0). Keyed by `kind`. */
const FURNITURE_RENDERERS: Record<string, (hot: boolean) => React.ReactNode> = {
  rug: (h) => <Box p={[0, 0.02, 0]} s={[4.2, 0.04, 2.8]} c={PALETTE.olive} hot={h} />,
  sofa: (h) => (
    <>
      <Box p={[0, 0.35, 0]} s={[2.6, 0.5, 1.1]} c={PALETTE.sand} hot={h} />
      <Box p={[0, 0.85, -0.45]} s={[2.6, 0.6, 0.22]} c={PALETTE.sand} hot={h} />
      <Box p={[-1.3, 0.65, 0]} s={[0.22, 0.45, 1.1]} c={PALETTE.sand} hot={h} />
      <Box p={[1.3, 0.65, 0]} s={[0.22, 0.45, 1.1]} c={PALETTE.sand} hot={h} />
      <Box p={[-0.65, 0.68, -0.15]} s={[0.55, 0.35, 0.5]} c={PALETTE.teal} hot={h} />
      <Box p={[0.65, 0.68, -0.15]} s={[0.55, 0.35, 0.5]} c={PALETTE.olive} hot={h} />
    </>
  ),
  coffee_table: (h) => (
    <>
      <Box p={[0, 0.42, 0]} s={[1.4, 0.06, 0.7]} c={PALETTE.bark} hot={h} />
      <Box p={[-0.6, 0.2, 0]} s={[0.06, 0.4, 0.6]} c={PALETTE.bark} hot={h} />
      <Box p={[0.6, 0.2, 0]} s={[0.06, 0.4, 0.6]} c={PALETTE.bark} hot={h} />
    </>
  ),
  floor_lamp: (h) => (
    <>
      <Cyl p={[0, 0.02, 0]} r={0.18} h={0.04} c={PALETTE.pine} hot={h} />
      <Cyl p={[0, 0.85, 0]} r={0.025} h={1.7} c={PALETTE.pine} hot={h} />
      <Cyl p={[0, 1.75, 0]} r={0.22} h={0.3} c={PALETTE.sand} hot={h} />
    </>
  ),
  media_console: (h) => <Box p={[0, 0.3, 0]} s={[2.0, 0.6, 0.45]} c={PALETTE.bark} hot={h} />,
  art_triptych: (h) => (
    <>
      <Box p={[-0.9, 1.9, 0]} s={[0.8, 1.0, 0.05]} c={PALETTE.teal} hot={h} />
      <Box p={[0, 1.9, 0]} s={[0.8, 1.0, 0.05]} c={PALETTE.olive} hot={h} />
      <Box p={[0.9, 1.9, 0]} s={[0.8, 1.0, 0.05]} c={PALETTE.bark} hot={h} />
    </>
  ),
  art_print: (h) => <Box p={[0, 1.9, 0]} s={[1.4, 0.9, 0.05]} c={PALETTE.teal} hot={h} />,
  dining_table: (h) => (
    <>
      <Box p={[0, 0.74, 0]} s={[2.4, 0.07, 1.1]} c={PALETTE.bark} hot={h} />
      {[[-1.05, -0.45], [1.05, -0.45], [-1.05, 0.45], [1.05, 0.45]].map(([x, z], i) => (
        <Box key={i} p={[x, 0.36, z]} s={[0.08, 0.72, 0.08]} c={PALETTE.bark} hot={h} />
      ))}
    </>
  ),
  chair: (h) => <Chair hot={h} />,
  pendant: (h) => (
    <>
      <Cyl p={[0, 2.55, 0]} r={0.015} h={1.1} c={PALETTE.pine} hot={h} />
      <Cyl p={[0, 1.95, 0]} r={0.28} h={0.25} c={PALETTE.teal} hot={h} />
    </>
  ),
  bed_king: (h) => <Bed hot={h} w={2.0} />,
  bed_queen: (h) => <Bed hot={h} w={1.7} />,
  bed_twin: (h) => <Bed hot={h} w={1.2} />,
  nightstand: (h) => <Box p={[0, 0.28, 0]} s={[0.55, 0.56, 0.45]} c={PALETTE.bark} hot={h} />,
  table_lamp: (h) => (
    <>
      <Cyl p={[0, 0.62, 0]} r={0.03} h={0.28} c={PALETTE.pine} hot={h} />
      <Cyl p={[0, 0.85, 0]} r={0.14} h={0.18} c={PALETTE.sand} hot={h} />
    </>
  ),
  plant: (h) => (
    <>
      <Cyl p={[0, 0.25, 0]} r={0.22} h={0.5} c={PALETTE.bark} hot={h} />
      <mesh position={[0, 0.95, 0]}>
        <sphereGeometry args={[0.45, 16, 16]} />
        <meshStandardMaterial color={PALETTE.olive} emissive={h ? PALETTE.teal : '#000000'} emissiveIntensity={h ? 0.55 : 0} roughness={0.9} />
      </mesh>
    </>
  ),
};

function Chair({ hot }: { hot: boolean }) {
  return (
    <>
      <Box p={[0, 0.45, 0]} s={[0.45, 0.05, 0.45]} c={PALETTE.bark} hot={hot} />
      <Box p={[0, 0.85, -0.2]} s={[0.45, 0.75, 0.05]} c={PALETTE.bark} hot={hot} />
      {[[-0.18, -0.18], [0.18, -0.18], [-0.18, 0.18], [0.18, 0.18]].map(([x, z], i) => (
        <Box key={i} p={[x, 0.22, z]} s={[0.05, 0.44, 0.05]} c={PALETTE.pine} hot={hot} />
      ))}
    </>
  );
}

function Bed({ hot, w }: { hot: boolean; w: number }) {
  return (
    <>
      <Box p={[0, 0.25, 0]} s={[w, 0.3, 2.2]} c={PALETTE.bark} hot={hot} />
      <Box p={[0, 0.48, 0.1]} s={[w - 0.15, 0.22, 2.0]} c={PALETTE.sand} hot={hot} />
      <Box p={[0, 0.85, -1.05]} s={[w, 0.9, 0.12]} c={PALETTE.bark} hot={hot} />
      <Box p={[-w / 4, 0.62, -0.75]} s={[w / 2 - 0.15, 0.14, 0.45]} c={'#ffffff'} hot={hot} />
      <Box p={[w / 4, 0.62, -0.75]} s={[w / 2 - 0.15, 0.14, 0.45]} c={'#ffffff'} hot={hot} />
      <Box p={[0, 0.55, 0.55]} s={[w - 0.1, 0.1, 1.0]} c={PALETTE.olive} hot={hot} />
    </>
  );
}

/* --------------------------- FURNITURE NODE WRAPPER -------------------------------- */
interface FurnitureNodeProps {
  placement: FurniturePlacement;
  selectedId: string | null;
  onSelect: (meta: FurnitureAssetMeta) => void;
}

/** Individually addressable staging asset — the future product-selection unit. */
function FurnitureNode({ placement, selectedId, onSelect }: FurnitureNodeProps) {
  const [hovered, setHovered] = useState(false);
  const { meta } = placement;
  const hot = hovered || selectedId === meta.id;
  const render = FURNITURE_RENDERERS[meta.kind];
  if (!render) return null;
  return (
    <group
      name={meta.id} // node name doubles as asset key (GLTF convention compatible)
      position={placement.position}
      rotation={[0, placement.rotationY ?? 0, 0]}
      userData={{ assetId: meta.id, category: meta.category, selectable: meta.selectable, productId: meta.productId }}
      onClick={(e) => { e.stopPropagation(); onSelect(meta); }}
      onPointerOver={(e) => { e.stopPropagation(); setHovered(true); document.body.style.cursor = 'pointer'; }}
      onPointerOut={() => { setHovered(false); document.body.style.cursor = 'auto'; }}
    >
      {render(hot)}
    </group>
  );
}

/* ------------------------------ WALL CONSTRUCTION ---------------------------------- */
interface WallOpening {
  c: number;      // centre along the wall run (metres from wall start)
  w: number;      // opening width
  y0: number;     // bottom of opening
  y1: number;     // top of opening
  glass?: boolean;
}

/**
 * One wall run with openings (windows / doors). Axis 'x' → runs along X at fixed z;
 * axis 'z' → runs along Z at fixed x. Solids are split around openings, with a sill
 * below and a header above each one; glass openings get a pane. `upperFrom/upperColor`
 * paint everything above the first storey in a contrasting cladding colour.
 */
function Wall({ axis, at, from, to, H, T, color, glassColor, openings = [], upperFrom, upperColor }: {
  axis: 'x' | 'z';
  at: number;
  from: number;
  to: number;
  H: number;
  T: number;
  color: string;
  glassColor: string;
  openings?: WallOpening[];
  upperFrom?: number;
  upperColor?: string;
}) {
  const parts: React.ReactNode[] = [];
  const sorted = [...openings].sort((a, b) => a.c - b.c);
  const solid = (y0: number) =>
    upperColor && upperFrom !== undefined && y0 >= upperFrom - 0.001 ? upperColor : color;
  const put = (c0: number, c1: number, y0: number, y1: number, c: string, thin = false) => {
    if (c1 - c0 < 0.02 || y1 - y0 < 0.02) return;
    const mid = (c0 + c1) / 2;
    const t = thin ? 0.1 : T; // glass panes sit thinner than the wall to avoid z-fighting
    const p: V3 = axis === 'x' ? [mid, (y0 + y1) / 2, at] : [at, (y0 + y1) / 2, mid];
    const s: V3 = axis === 'x' ? [c1 - c0, y1 - y0, t] : [t, y1 - y0, c1 - c0];
    parts.push(<Box key={`${axis}${at}-${mid}-${y0}`} p={p} s={s} c={c} />);
  };
  const putSolid = (c0: number, c1: number, y0: number, y1: number) => {
    // split at the upper-cladding line so the accent band stays clean
    if (upperColor && upperFrom !== undefined && y0 < upperFrom && y1 > upperFrom) {
      put(c0, c1, y0, upperFrom, color);
      put(c0, c1, upperFrom, y1, upperColor);
    } else {
      put(c0, c1, y0, y1, solid(y0));
    }
  };
  let cursor = from;
  for (const o of sorted) {
    const o0 = o.c - o.w / 2, o1 = o.c + o.w / 2;
    putSolid(cursor, o0, 0, H);              // solid before opening
    putSolid(o0, o1, 0, o.y0);               // sill
    putSolid(o0, o1, o.y1, H);               // header
    if (o.glass) put(o0 + 0.02, o1 - 0.02, o.y0, o.y1, glassColor, true);
    cursor = o1;
  }
  putSolid(cursor, to, 0, H);                // solid after last opening
  return <>{parts}</>;
}

/* ------------------------------ ARCHITECTURE LAYER --------------------------------- */
/** Structural shell generated from the photo-matched spec: slab, exterior walls +
    glazing (upper storey rows where the photo shows two storeys), interior partitions
    sized to the bedroom count, built-in kitchen millwork, entry door. */
function ArchitectureLayer({ spec }: { spec: HouseSpec }) {
  const { width: W, depth: D, wallH, totalH, partitionX: px, bedrooms, storeys } = spec;
  const T = 0.24;
  const W_ = spec.wallColor, G = spec.glassColor, F = spec.floorColor;
  const rand = seededRandom(spec.seed + 7);
  const two = storeys > 1;
  const boost = spec.glassBoost ? 1.5 : 1;

  // South wall: 2–3 windows in the living zone + one per bedroom
  const southOpenings: WallOpening[] = [];
  const livingSpan = px + W / 2 - 2.4;
  const livingWinCount = 2 + Math.floor(rand() * 2);
  for (let i = 0; i < livingWinCount; i++) {
    const c = 1.2 + i * (livingSpan / Math.max(1, livingWinCount - 1));
    const w = Math.min((1.6 + rand() * 0.8) * boost, livingSpan / livingWinCount - 0.3);
    southOpenings.push({ c, w, y0: spec.glassBoost ? 0.25 : 0.45, y1: wallH - 0.45, glass: true });
  }
  const wingStart = px + W / 2; // metres from west edge
  const wingMid = wingStart + (W / 2 - px) / 2;
  for (let i = 0; i < bedrooms; i++) {
    const c = wingMid + (i - (bedrooms - 1) / 2) * 0.3;
    southOpenings.push({ c, w: 1.3 * boost, y0: 0.6, y1: wallH - 0.7, glass: true });
    if (two) southOpenings.push({ c, w: 1.3, y0: wallH + 0.55, y1: totalH - 0.5, glass: true });
  }
  if (two) {
    for (let i = 0; i < livingWinCount; i++) {
      const c = 1.2 + i * (livingSpan / Math.max(1, livingWinCount - 1));
      southOpenings.push({ c, w: Math.min(1.6, livingSpan / livingWinCount - 0.3), y0: wallH + 0.55, y1: totalH - 0.5, glass: true });
    }
  }

  // North wall: wide glass doors in the open plan (+ upper windows when two storeys)
  const doorW = Math.min(6 * boost, px + W / 2 - 2);
  const northOpenings: WallOpening[] = [
    { c: (px + W / 2) * 0.45, w: doorW, y0: 0.15, y1: wallH - 0.45, glass: true },
  ];
  if (two) {
    for (let i = 0; i < 3; i++) {
      northOpenings.push({ c: 2 + i * ((W - 4) / 2), w: 1.4, y0: wallH + 0.55, y1: totalH - 0.5, glass: true });
    }
  }

  // West wall: horizontal band window (+ upper band when two storeys)
  const westOpenings: WallOpening[] = [
    { c: D / 2, w: Math.min(5 * boost, D - 2), y0: 0.9, y1: wallH - 0.5, glass: true },
  ];
  if (two) westOpenings.push({ c: D / 2, w: Math.min(4, D - 2.5), y0: wallH + 0.55, y1: totalH - 0.55, glass: true });

  // East wall: entry door + small window (+ upper windows when two storeys)
  const eastOpenings: WallOpening[] = [
    { c: D * 0.25, w: 1.1, y0: 0, y1: 2.2 },
    { c: D * 0.7, w: 1.2, y0: 1.1, y1: wallH - 0.8, glass: true },
  ];
  if (two) {
    eastOpenings.push({ c: D * 0.3, w: 1.2, y0: wallH + 0.55, y1: totalH - 0.6, glass: true });
    eastOpenings.push({ c: D * 0.7, w: 1.2, y0: wallH + 0.55, y1: totalH - 0.6, glass: true });
  }

  // Bedroom-wing partitions (per bedroom)
  const partitions: React.ReactNode[] = [];
  const seg = D / bedrooms;
  for (let i = 1; i < bedrooms; i++) {
    partitions.push(
      <Wall
        key={`bp${i}`}
        axis="x" at={-D / 2 + seg * i} from={px} to={W / 2} H={wallH} T={T} color={W_} glassColor={G}
        openings={[]}
      />,
    );
  }

  // Main partition between open plan and bedroom wing, with a doorway
  const mainPartition = (
    <Wall
      axis="z" at={px} from={-D / 2} to={D / 2} H={wallH} T={T} color={W_} glassColor={G}
      openings={[{ c: D * 0.1 + D / 2, w: 1.2, y0: 0, y1: 2.2 }]}
    />
  );

  // Built-in kitchen millwork along the north wall of the dining zone
  const kx = -W / 2 + W * 0.42;
  const kitchen = (
    <>
      <Box p={[kx, 0.45, D / 2 - 0.45]} s={[Math.min(4.6, W * 0.3), 0.9, 0.6]} c={'#b9ac93'} />
      <Box p={[kx, 0.93, D / 2 - 0.45]} s={[Math.min(4.7, W * 0.3 + 0.1), 0.06, 0.7]} c={PALETTE.pine} />
      <Box p={[px - 0.45, 0.45, D / 2 - 2.2]} s={[0.6, 0.9, 2.8]} c={'#b9ac93'} />
      <Box p={[px - 0.45, 0.93, D / 2 - 2.2]} s={[0.7, 0.06, 2.9]} c={PALETTE.pine} />
    </>
  );

  // Entry door panel (matches the photo's front door on the east wall)
  const door = (
    <Box p={[W / 2 + 0.02, 1.1, -D / 2 + D * 0.25]} s={[0.08, 2.2, 1.06]} c={PALETTE.pine} />
  );

  const upper = two && spec.accentColor ? { upperFrom: wallH, upperColor: spec.accentColor } : {};

  return (
    <group name="arch_structure">
      <Box p={[0, -0.05, 0]} s={[W, 0.2, D]} c={F} />
      <Wall axis="x" at={-D / 2} from={-W / 2} to={W / 2} H={totalH} T={T} color={W_} glassColor={G} openings={southOpenings} {...upper} />
      <Wall axis="x" at={D / 2} from={-W / 2} to={W / 2} H={totalH} T={T} color={W_} glassColor={G} openings={northOpenings} {...upper} />
      <Wall axis="z" at={-W / 2} from={-D / 2} to={D / 2} H={totalH} T={T} color={W_} glassColor={G} openings={westOpenings} {...upper} />
      <Wall axis="z" at={W / 2} from={-D / 2} to={D / 2} H={totalH} T={T} color={W_} glassColor={G} openings={eastOpenings} {...upper} />
      {mainPartition}
      {partitions}
      {kitchen}
      {door}
    </group>
  );
}

/* ------------------------------- PORCH & GARAGE ------------------------------------ */
/** Covered entry porch on the east (door) side — flat canopy or gabled, per photo. */
function Porch({ spec }: { spec: HouseSpec }) {
  const { width: W, depth: D } = spec;
  const pw = Math.min(5, D * 0.6);   // porch length along z
  const px = W / 2 + 1.15;           // deck centre
  const canopyY = 2.45;

  const gableGeom = useMemo(() => {
    if (spec.porch !== 'gable') return null;
    const shape = new THREE.Shape();
    shape.moveTo(-1.4, 0);
    shape.lineTo(1.4, 0);
    shape.lineTo(0, 0.75);
    shape.closePath();
    const g = new THREE.ExtrudeGeometry(shape, { depth: pw, bevelEnabled: false });
    g.rotateY(Math.PI / 2);
    return g;
  }, [spec.porch, pw]);

  return (
    <group name="arch_porch">
      {/* deck */}
      <Box p={[px, 0.09, 0]} s={[2.5, 0.18, pw]} c={'#c7bdab'} />
      {/* posts */}
      {[[W / 2 + 2.25, -pw / 2 + 0.15], [W / 2 + 2.25, pw / 2 - 0.15]].map(([x, z], i) => (
        <Cyl key={i} p={[x, canopyY / 2 + 0.1, z]} r={0.09} h={canopyY - 0.1} c={spec.wallColor} />
      ))}
      {/* canopy */}
      {spec.porch === 'gable' && gableGeom ? (
        <mesh geometry={gableGeom} position={[px + 1.3, canopyY, 0]} castShadow>
          <meshStandardMaterial color={spec.roofColor} roughness={0.9} side={THREE.DoubleSide} />
        </mesh>
      ) : (
        <Box p={[px, canopyY + 0.08, 0]} s={[2.7, 0.16, pw + 0.3]} c={spec.roofColor} />
      )}
    </group>
  );
}

/** Attached garage on the west side, with a panel door facing the street (south). */
function Garage({ spec }: { spec: HouseSpec }) {
  const { width: W, depth: D } = spec;
  const gx = -W / 2 - 2.5;
  const gz = -D / 2 + 2.6;
  return (
    <group name="arch_garage">
      <Box p={[gx, 1.3, gz]} s={[5, 2.6, 5.2]} c={spec.wallColor} />
      <Box p={[gx, 2.72, gz]} s={[5.3, 0.25, 5.5]} c={spec.roofColor} />
      {/* garage door */}
      <Box p={[gx, 1.05, gz - 2.63]} s={[3.4, 2.1, 0.08]} c={'#8b8f94'} />
      {[0.5, 1.05, 1.6].map((y) => (
        <Box key={y} p={[gx, y, gz - 2.68]} s={[3.4, 0.04, 0.02]} c={'#6f7378'} />
      ))}
      {/* side window */}
      <Box p={[gx + 2.53, 1.6, gz]} s={[0.08, 0.9, 1.4]} c={spec.glassColor} />
    </group>
  );
}

/* --------------------------------- ROOF LAYER -------------------------------------- */
/** Separate structural group (roof + dormers + chimney). ROOF OFF lifts the whole
    assembly +Y and fades it out so the floor plan reads clearly. Geometry comes from
    the photo-matched spec: gable / steep / hip / flat. */
function RoofLayer({ roofOn, spec }: { roofOn: boolean; spec: HouseSpec }) {
  const group = useRef<THREE.Group>(null);
  const opacity = useRef(1);

  const gableGeom = useMemo(() => {
    if (spec.roofStyle === 'flat' || spec.roofStyle === 'hip') return null;
    const half = spec.depth / 2 + 0.6;
    const shape = new THREE.Shape();
    shape.moveTo(-half, 0);
    shape.lineTo(half, 0);
    shape.lineTo(0, spec.roofRise);
    shape.closePath();
    const g = new THREE.ExtrudeGeometry(shape, { depth: spec.width + 1.4, bevelEnabled: false });
    g.rotateY(Math.PI / 2); // ridge along X axis
    return g;
  }, [spec]);

  const hipGeom = useMemo(() => {
    if (spec.roofStyle !== 'hip') return null;
    const g = new THREE.CylinderGeometry(0.001, 1, spec.roofRise, 4, 1);
    g.rotateY(Math.PI / 4); // square base aligned to axes
    g.scale((spec.width + 1.4) / Math.SQRT2, 1, (spec.depth + 1.4) / Math.SQRT2);
    g.translate(0, spec.roofRise / 2, 0);
    return g;
  }, [spec]);

  const dormerGeom = useMemo(() => {
    if (!spec.dormers) return null;
    const shape = new THREE.Shape();
    shape.moveTo(-0.7, 0);
    shape.lineTo(0.7, 0);
    shape.lineTo(0, 0.55);
    shape.closePath();
    const g = new THREE.ExtrudeGeometry(shape, { depth: 1.2, bevelEnabled: false });
    g.rotateY(Math.PI / 2);
    return g;
  }, [spec.dormers]);

  useFrame(() => {
    const g = group.current;
    if (!g) return;
    const targetY = roofOn ? spec.totalH : spec.totalH + 4.5; // lift when roof removed
    const targetOpacity = roofOn ? 1 : 0;                     // fade so the floor plan reads
    g.position.y = THREE.MathUtils.lerp(g.position.y, targetY, 0.08);
    opacity.current = THREE.MathUtils.lerp(opacity.current, targetOpacity, 0.08);
    const o = opacity.current;
    g.traverse((node: any) => {
      if (node.isMesh) {
        const m = node.material as THREE.MeshStandardMaterial;
        m.transparent = true;
        m.opacity = o;
        m.depthWrite = o > 0.4;      // avoid translucent-sorting artifacts while faded
        node.castShadow = o > 0.4;   // no shadow from a ghost roof
      }
    });
    g.visible = o > 0.02;            // fully hide once invisible
  });

  const dormers = [];
  if (spec.dormers && dormerGeom) {
    for (let i = 0; i < spec.dormers; i++) {
      const x = spec.width * (spec.dormers === 1 ? 0.05 : -0.15 + i * 0.35) - spec.width * 0.1;
      dormers.push(
        <group key={i} position={[x, spec.roofRise * 0.28, -(spec.depth / 2 + 0.6) * 0.52]}>
          <mesh castShadow>
            <boxGeometry args={[1.2, 0.85, 1.1]} />
            <meshStandardMaterial color={spec.wallColor} roughness={0.85} />
          </mesh>
          <mesh geometry={dormerGeom} position={[0.6, 0.85, 0]} castShadow>
            <meshStandardMaterial color={spec.roofColor} roughness={0.9} side={THREE.DoubleSide} />
          </mesh>
          <mesh position={[0, 0.42, -0.56]}>
            <boxGeometry args={[0.7, 0.55, 0.05]} />
            <meshStandardMaterial color={spec.glassColor} roughness={0.6} />
          </mesh>
        </group>,
      );
    }
  }

  if (spec.roofStyle === 'flat') {
    return (
      <group ref={group} name="roof_structure" position={[0, spec.totalH + 0.18, 0]}>
        <mesh castShadow>
          <boxGeometry args={[spec.width + 0.6, 0.35, spec.depth + 0.6]} />
          <meshStandardMaterial color={spec.roofColor} roughness={0.92} />
        </mesh>
        <mesh position={[0, 0.28, 0]} castShadow>
          <boxGeometry args={[spec.width + 0.75, 0.22, spec.depth + 0.75]} />
          <meshStandardMaterial color={PALETTE.bark} roughness={0.85} />
        </mesh>
        {spec.chimney && (
          <mesh position={[spec.width * 0.25, 0.7, 0]} castShadow>
            <boxGeometry args={[0.7, 1.4, 0.7]} />
            <meshStandardMaterial color={'#8a8a86'} roughness={0.95} />
          </mesh>
        )}
      </group>
    );
  }

  if (spec.roofStyle === 'hip') {
    return (
      <group ref={group} name="roof_structure" position={[0, spec.totalH, 0]}>
        <mesh geometry={hipGeom ?? undefined} castShadow>
          <meshStandardMaterial color={spec.roofColor} roughness={0.92} side={THREE.DoubleSide} />
        </mesh>
        {spec.chimney && (
          <mesh position={[spec.width * 0.28, spec.roofRise * 0.55, spec.depth * 0.15]} castShadow>
            <boxGeometry args={[0.7, spec.roofRise + 0.9, 0.7]} />
            <meshStandardMaterial color={'#8a8a86'} roughness={0.95} />
          </mesh>
        )}
      </group>
    );
  }

  return (
    <group ref={group} name="roof_structure" position={[-(spec.width + 1.4) / 2, spec.totalH, 0]}>
      <mesh geometry={gableGeom ?? undefined} castShadow>
        <meshStandardMaterial color={spec.roofColor} roughness={0.92} side={THREE.DoubleSide} />
      </mesh>
      {/* fascia beam */}
      <mesh position={[(spec.width + 1.4) / 2, -0.06, 0]} castShadow>
        <boxGeometry args={[spec.width + 1.6, 0.14, spec.depth + 1.4]} />
        <meshStandardMaterial color={PALETTE.bark} roughness={0.85} />
      </mesh>
      {dormers}
      {spec.chimney && (
        <mesh position={[(spec.width + 1.4) / 2 + spec.width * 0.2, spec.roofRise * 0.5, 0]} castShadow>
          <boxGeometry args={[0.7, spec.roofRise + 1.0, 0.7]} />
          <meshStandardMaterial color={'#8a8a86'} roughness={0.95} />
        </mesh>
      )}
    </group>
  );
}

/* --------------------------------- SCENE ------------------------------------------- */
interface SceneProps {
  spec: HouseSpec;
  furniture: FurniturePlacement[];
  roofOn: boolean;
  furnished: boolean;
  selectedId: string | null;
  onSelect: (meta: FurnitureAssetMeta | null) => void;
}

function PropertyScene({ spec, furniture, roofOn, furnished, selectedId, onSelect }: SceneProps) {
  const controls = useRef<any>(null);
  const groundR = Math.max(30, spec.width * 2.2);
  return (
    <>
      {/* soft sky + gentle atmospheric haze */}
      <color attach="background" args={['#dfe4d8']} />
      <fog attach="fog" args={['#dfe4d8', 34, 78]} />

      <hemisphereLight args={['#f4efe4', '#8a9478', 0.85]} />
      <directionalLight
        position={[12, 16, 9]}
        intensity={1.6}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-left={-18}
        shadow-camera-right={18}
        shadow-camera-top={18}
        shadow-camera-bottom={-18}
        shadow-bias={-0.0004}
      />
      <directionalLight position={[-8, 10, -6]} intensity={0.3} />

      {/* grounds: lawn with a stone terrace */}
      <mesh position={[0, -0.18, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <circleGeometry args={[groundR, 48]} />
        <meshStandardMaterial color={'#a9b58c'} roughness={1} />
      </mesh>
      <mesh position={[0, -0.12, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow onClick={() => onSelect(null)}>
        <circleGeometry args={[Math.max(13, spec.width), 40]} />
        <meshStandardMaterial color={'#9aa87e'} roughness={1} />
      </mesh>
      <mesh position={[0, -0.1, spec.depth / 2 + 3.4]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[spec.width * 0.8, 6]} />
        <meshStandardMaterial color={'#c7bdab'} roughness={0.95} />
      </mesh>

      <ArchitectureLayer spec={spec} />
      {spec.porch && <Porch spec={spec} />}
      {spec.garage && <Garage spec={spec} />}
      <RoofLayer roofOn={roofOn} spec={spec} />

      {/* FURNISHING LAYER — single switch, independent of roof */}
      <group name="furnishing_layer" visible={furnished}>
        {furniture.map((placement) => (
          <FurnitureNode
            key={placement.meta.id}
            placement={placement}
            selectedId={selectedId}
            onSelect={onSelect}
          />
        ))}
      </group>

      <OrbitControls
        ref={controls}
        makeDefault
        enableDamping
        dampingFactor={0.08}
        minDistance={5}
        maxDistance={Math.max(30, spec.width * 2.4)}
        maxPolarAngle={Math.PI / 2.05}
        target={[0, spec.totalH * 0.35, 0]}
      />
    </>
  );
}

/* ------------------------------- UI SHELL ------------------------------------------ */
export function Property3DExperience({
  propertyTitle,
  property,
  modelUrl,
}: {
  propertyTitle: string;
  property?: PropertySpecInput;  // listing specs → reconstructs this home from its photo
  modelUrl?: string;             // FUTURE: production GLTF digital twin per listing
}) {
  const [roofOn, setRoofOn] = useState(true);
  const [furnished, setFurnished] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [selected, setSelected] = useState<FurnitureAssetMeta | null>(null);
  const canvasKey = useRef(0);
  void modelUrl; // reserved for the GLTF digital-twin upgrade path

  const spec = useMemo(() => generateHouseSpec(property), [property?.id, property?.beds, property?.baths, property?.sqft, property?.type]);
  const furniture = useMemo(() => buildFurniturePlan(spec), [spec]);

  const caption = roofOn
    ? furnished ? 'Exterior view · Staged interior' : 'Exterior view · Unstaged'
    : furnished ? 'Roof removed · Staged interior' : 'Roof removed · Floor plan view';

  const pill = (active: boolean) =>
    `px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
      active
        ? 'bg-[#263F35] text-[#E7E0D2] shadow-md'
        : 'text-[#263F35]/70 hover:bg-[#263F35]/10'
    }`;

  const camD = Math.max(spec.width, spec.depth, spec.totalH * 1.8) * 1.05 + 5;

  return (
    <section className="space-y-4">
      <div className="flex items-end justify-between border-b border-[#263F35]/10 pb-3">
        <div>
          <h3 className="text-2xl font-serif font-bold text-[#263F35]">Explore This Home in 3D</h3>
          <p className="text-sm text-[#263F35]/60 mt-1">
            {propertyTitle} — lift the roof, step inside, and look around, all from your browser.
          </p>
          <p className="text-xs text-[#28717A] mt-1 tracking-wide">
            3D reconstruction from the listing photo — {spec.label}
          </p>
        </div>
        <span className="hidden sm:inline-block text-xs tracking-[0.2em] uppercase text-[#263F35]/40">
          Interactive
        </span>
      </div>

      <div
        className={
          isFullscreen
            ? 'fixed inset-0 z-50 bg-[#E7E0D2]'
            : 'relative w-full aspect-[16/9] rounded-2xl overflow-hidden shadow-xl border border-[#263F35]/10'
        }
      >
        <Canvas
          key={canvasKey.current}
          shadows
          camera={{ position: [camD, camD * 0.72, camD], fov: 42 }}
          gl={{ antialias: true }}
          onCreated={({ gl }) => gl.setClearColor('#dfe4d8')}
        >
          <PropertyScene
            spec={spec}
            furniture={furniture}
            roofOn={roofOn}
            furnished={furnished}
            selectedId={selected?.id ?? null}
            onSelect={setSelected}
          />
        </Canvas>

        {/* soft photographic vignette */}
        <div className="pointer-events-none absolute inset-0 shadow-[inset_0_0_90px_rgba(38,63,53,0.22)]" />

        {/* status pill */}
        <div className="absolute top-3 left-3 px-3 py-1.5 rounded-full bg-[#E7E0D2]/90 backdrop-blur text-xs font-medium text-[#263F35] shadow">
          {caption}
        </div>

        {/* controls — roof and furnishing are independent switches */}
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex flex-wrap justify-center gap-2 px-2 max-w-full">
          <div className="flex bg-[#E7E0D2]/95 backdrop-blur rounded-full p-1 shadow-lg border border-[#263F35]/10">
            <button className={pill(roofOn)} onClick={() => setRoofOn(true)}>Roof On</button>
            <button className={pill(!roofOn)} onClick={() => setRoofOn(false)}>Roof Off</button>
          </div>
          <div className="flex bg-[#E7E0D2]/95 backdrop-blur rounded-full p-1 shadow-lg border border-[#263F35]/10">
            <button className={pill(furnished)} onClick={() => setFurnished(true)}>Furnished</button>
            <button className={pill(!furnished)} onClick={() => setFurnished(false)}>Unfurnished</button>
          </div>
          <div className="flex bg-[#E7E0D2]/95 backdrop-blur rounded-full p-1 shadow-lg border border-[#263F35]/10">
            <button className={pill(false)} onClick={() => { canvasKey.current += 1; setSelected(null); }}>
              Reset View
            </button>
            <button className={pill(false)} onClick={() => setIsFullscreen((f) => !f)}>
              {isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
            </button>
          </div>
        </div>

        {/* hint */}
        <div className="absolute bottom-3 right-3 hidden md:block text-[11px] text-[#263F35]/50 bg-[#E7E0D2]/80 rounded-full px-3 py-1">
          Drag to look around · Scroll to zoom · Click a piece of furniture
        </div>

        {/* selected furniture card — the future product slot */}
        {selected && (
          <div className="absolute top-3 right-3 w-56 bg-[#E7E0D2]/95 backdrop-blur rounded-xl shadow-lg border border-[#263F35]/10 p-4">
            <p className="text-[10px] tracking-[0.2em] uppercase text-[#28717A] font-semibold">{selected.room}</p>
            <p className="font-serif font-bold text-[#263F35] mt-1">{selected.name}</p>
            <p className="text-xs text-[#263F35]/60 mt-1">{selected.category}</p>
            <button
              onClick={() => setSelected(null)}
              className="mt-3 text-xs text-[#28717A] hover:text-[#263F35] font-medium"
            >
              Close
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
