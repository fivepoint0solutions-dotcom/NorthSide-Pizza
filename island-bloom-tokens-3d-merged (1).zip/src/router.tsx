import { QueryClient } from "@tanstack/react-query";
import { createRouter, createHashHistory, createMemoryHistory } from "@tanstack/react-router";
import { routeTree } from "./routeTree.gen";

export const getRouter = () => {
  const queryClient = new QueryClient();

  const router = createRouter({
    routeTree,
    // Hash history keeps all navigation client-side so the site works
    // when served as plain static files (no server rewrites needed).
    // Memory history is used during SSR where no window exists.
    history: typeof window !== "undefined" ? createHashHistory() : createMemoryHistory(),
    context: { queryClient },
    scrollRestoration: true,
    defaultPreloadStaleTime: 0,
  });

  return router;
};
