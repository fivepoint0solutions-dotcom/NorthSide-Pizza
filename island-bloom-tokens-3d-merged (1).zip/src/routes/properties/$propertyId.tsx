import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { properties, formatPrice } from "@/data/properties";
import { Reveal } from "@/components/motion/Reveal";
import { SmoothImage } from "@/components/motion/SmoothImage";
import { Button } from "@/components/ui/button";
import { Property3DExperience } from "@/components/property3d/Property3DExperience";

export const Route = createFileRoute("/properties/$propertyId")({
  loader: ({ params }) => {
    const property = properties.find((p) => p.id === params.propertyId);
    if (!property) throw notFound();
    return { property };
  },
  head: ({ loaderData }) => {
    const name = loaderData?.property.title ?? "Property";
    const title = `${name} — West Coast Realty`;
    const description = loaderData
      ? `${name} in ${loaderData.property.city}: ${loaderData.property.beds} beds, ${loaderData.property.baths} baths, ${loaderData.property.sqft} sq ft.`
      : "Victoria, BC property details from West Coast Realty.";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "article" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: PropertyDetailPage,
});

function PropertyDetailPage() {
  const { property } = Route.useLoaderData();

  return (
    <main className="min-h-screen bg-background pt-28">
      <div className="container-editorial pb-24">
        <Reveal>
          <Button asChild size="sm" className="bg-[#263F35] text-[#E7E0D2] hover:bg-[#28717A] shadow-md">
            <Link to="/properties">
              <ArrowLeft />
              Back to properties
            </Link>
          </Button>
          <p className="text-eyebrow mt-6 text-accent">
            {property.neighbourhood} · {property.status === "rent" ? "For Rent" : "For Sale"}
          </p>
          <h1 className="text-headline mt-3 text-primary">{property.title}</h1>
          <p className="text-lede mt-4 text-[color:var(--color-ring)]">
            {formatPrice(property.price)}
            {property.status === "rent" ? " / mo" : ""}
          </p>
        </Reveal>

        <Reveal delay={80} className="mt-10">
          <SmoothImage
            src={property.image}
            alt={property.imageAlt}
            ratio="aspect-[16/9]"
            className="h-full w-full object-cover"
            loading="eager"
          />
        </Reveal>

        <Reveal delay={140}>
          <dl className="mt-10 grid grid-cols-2 gap-6 border-t border-border pt-8 sm:grid-cols-4">
            {[
              ["City", property.city],
              ["Type", property.type],
              ["Bedrooms", String(property.beds)],
              ["Bathrooms", String(property.baths)],
            ].map(([label, value]) => (
              <div key={label}>
                <dt className="text-caption text-muted-foreground">{label}</dt>
                <dd className="text-title mt-1 text-primary">{value}</dd>
              </div>
            ))}
            <div>
              <dt className="text-caption text-muted-foreground">Interior</dt>
              <dd className="text-title mt-1 text-primary">
                {property.sqft.toLocaleString("en-CA")} sq ft
              </dd>
            </div>
          </dl>
        </Reveal>

        <Reveal delay={140} className="mt-12 max-w-3xl">
          <h2 className="text-heading-md font-serif text-foreground">About this home</h2>
          <p className="mt-4 text-body leading-relaxed text-muted-foreground">
            {property.description}
          </p>
        </Reveal>

        <Reveal delay={200} className="mt-14">
          <Property3DExperience propertyTitle={property.title} property={property} />
        </Reveal>
      </div>
    </main>
  );
}
