import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { properties, formatPrice, type Property } from "@/data/properties";
import { Reveal } from "@/components/motion/Reveal";
import { SmoothImage } from "@/components/motion/SmoothImage";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

const title = "Properties for Sale in Victoria, BC — West Coast Realty";
const description =
  "Search and filter 20 curated Victoria, BC homes: waterfront estates, heritage manors, and coastal retreats across Greater Victoria and the Saanich Peninsula.";

export const Route = createFileRoute("/properties/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PropertiesPage,
});

const statusPills = [
  { value: "all", label: "All" },
  { value: "sale", label: "For Sale" },
  { value: "rent", label: "For Rent" },
] as const;

const typeChips = ["House", "Condo", "Townhome", "Estate", "Cottage"] as const;

const sortOptions = [
  { value: "featured", label: "Featured" },
  { value: "price-desc", label: "Price: High to Low" },
  { value: "price-asc", label: "Price: Low to High" },
  { value: "sqft-desc", label: "Largest" },
  { value: "title-asc", label: "Name: A–Z" },
] as const;

function sortProperties(list: Property[], sort: string) {
  const sorted = [...list];
  switch (sort) {
    case "price-desc":
      return sorted.sort((a, b) => b.price - a.price);
    case "price-asc":
      return sorted.sort((a, b) => a.price - b.price);
    case "sqft-desc":
      return sorted.sort((a, b) => b.sqft - a.sqft);
    case "title-asc":
      return sorted.sort((a, b) => a.title.localeCompare(b.title));
    default:
      return sorted;
  }
}

function PropertiesPage() {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<string>("all");
  const [types, setTypes] = useState<string[]>([]);
  const [sort, setSort] = useState("featured");

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    const filtered = properties.filter((p) => {
      if (status !== "all" && p.status !== status) return false;
      if (types.length > 0 && !types.includes(p.type)) return false;
      if (!q) return true;
      return [p.title, p.city, p.neighbourhood, p.type]
        .join(" ")
        .toLowerCase()
        .includes(q);
    });
    return sortProperties(filtered, sort);
  }, [query, status, types, sort]);

  const toggleType = (t: string) =>
    setTypes((prev) => (prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]));

  return (
    <main className="min-h-screen bg-background pt-28">
      <div className="container-editorial">
        <Reveal>
          <p className="text-eyebrow text-accent">Greater Victoria</p>
          <h1 className="text-headline mt-3 text-primary">Properties</h1>
          <p className="text-lede measure mt-4 text-muted-foreground">
            A curated selection of {properties.length} homes across Victoria, Oak Bay,
            the Saanich Peninsula and the West Shore.
          </p>
        </Reveal>

        <div className="mt-10 flex flex-col gap-6">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by name, city or neighbourhood"
              aria-label="Search properties"
              className="md:max-w-sm"
            />
            <div className="flex items-center gap-3">
              <span className="text-caption text-muted-foreground">Sort</span>
              <Select value={sort} onValueChange={setSort}>
                <SelectTrigger className="w-[190px]" aria-label="Sort properties">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {sortOptions.map((o) => (
                    <SelectItem key={o.value} value={o.value}>
                      {o.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {statusPills.map((pill) => (
              <button
                key={pill.value}
                type="button"
                onClick={() => setStatus(pill.value)}
                aria-pressed={status === pill.value}
                className={cn(
                  "rounded-full border px-5 py-2 text-sm tracking-wide transition-colors duration-300",
                  status === pill.value
                    ? "border-transparent bg-[color:var(--color-ring)] text-primary-foreground"
                    : "border-border text-foreground hover:border-[color:var(--color-ring)] hover:text-[color:var(--color-ring)]",
                )}
              >
                {pill.label}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {typeChips.map((chip) => {
              const active = types.includes(chip);
              return (
                <button
                  key={chip}
                  type="button"
                  onClick={() => toggleType(chip)}
                  aria-pressed={active}
                  className={cn(
                    "rounded-sm border px-4 py-1.5 text-xs uppercase tracking-[0.14em] transition-colors duration-300",
                    active
                      ? "border-accent bg-accent/10 text-accent"
                      : "border-border text-muted-foreground hover:border-accent hover:text-accent",
                  )}
                >
                  {chip}
                </button>
              );
            })}
          </div>

          <p className="text-caption text-muted-foreground">
            {results.length} {results.length === 1 ? "property" : "properties"}
          </p>
        </div>

        <div className="mt-8 grid grid-cols-1 gap-8 pb-24 sm:grid-cols-2 lg:grid-cols-3">
          {results.map((property, i) => (
            <Reveal key={property.id} delay={(i % 3) * 80}>
              <Link
                to="/properties/$propertyId"
                params={{ propertyId: property.id }}
                className="hover-lift group block h-full overflow-hidden rounded-md border border-border bg-card shadow-sm"
              >
                <article className="flex h-full flex-col">
                  <SmoothImage
                    src={property.image}
                    alt={property.imageAlt}
                    ratio="aspect-[4/3]"
                    className="h-full w-full object-cover"
                  />
                  <div className="flex flex-1 flex-col gap-2 p-6">
                    <p className="text-caption text-muted-foreground">
                      {property.city} · {property.status === "rent" ? "For Rent" : "For Sale"}
                    </p>
                    <h2 className="text-title text-primary">{property.title}</h2>
                    <p className="mt-auto pt-3 font-medium tracking-wide text-[color:var(--color-ring)]">
                      {formatPrice(property.price)}
                      {property.status === "rent" ? " / mo" : ""}
                    </p>
                  </div>
                </article>
              </Link>
            </Reveal>
          ))}
        </div>

        {results.length === 0 && (
          <p className="pb-24 text-muted-foreground">
            No properties match those filters yet.
          </p>
        )}
      </div>
    </main>
  );
}
